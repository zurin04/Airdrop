import { useState, useEffect, useCallback, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type Message = {
  user: string;
  message: string;
  timestamp: string;
  isAdmin: boolean;
  isCreator?: boolean;
};

// Cache for user profile images
interface UserProfileCache {
  [username: string]: {
    image: string | null;
    lastFetched: number;
  };
}

type ChatPayload = {
  user: string;
  message: string;
  isAdmin: boolean;
  isCreator?: boolean;
};

export function useChat() {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnecting, setIsConnecting] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [onlineUsers, setOnlineUsers] = useState(0);
  const { toast } = useToast();
  
  // Profile image cache
  const profileCache = useRef<UserProfileCache>({});
  const [userProfileImages, setUserProfileImages] = useState<{[username: string]: string | null}>({});

  // Initialize WebSocket connection
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    console.log('Connecting to WebSocket:', wsUrl);
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('WebSocket connected successfully');
      setSocket(ws);
      setIsConnecting(false);
    };
    
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === "message") {
          setMessages((prev) => [...prev, data.payload]);
        } else if (data.type === "status") {
          setOnlineUsers(data.online);
        } else if (data.type === "history") {
          setMessages(data.messages);
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };
    
    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      setIsConnecting(false);
      toast({
        title: "Chat Connection Error",
        description: "Could not connect to the chat service. Please try again later.",
        variant: "destructive",
      });
    };
    
    ws.onclose = () => {
      setIsConnecting(false);
      toast({
        title: "Chat Disconnected",
        description: "You have been disconnected from the chat service.",
        variant: "destructive",
      });
    };
    
    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, [toast]);

  // Fetch user profile image and cache it
  const fetchUserProfileImage = useCallback(async (username: string) => {
    // Check if we already have a recent cached version (within 5 minutes)
    const cachedData = profileCache.current[username];
    const now = Date.now();
    const cacheExpiryTime = 5 * 60 * 1000; // 5 minutes cache
    
    if (cachedData && (now - cachedData.lastFetched < cacheExpiryTime)) {
      return cachedData.image;
    }
    
    try {
      const response = await fetch(`/api/users/profile-image/${username}`, {
        method: 'GET',
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        const profileImage = data.profile_image || null;
        
        // Update the cache
        profileCache.current[username] = {
          image: profileImage,
          lastFetched: now
        };
        
        // Update the state
        setUserProfileImages(prev => ({
          ...prev,
          [username]: profileImage
        }));
        
        return profileImage;
      }
    } catch (error) {
      console.error('Error fetching user profile image:', error);
      
      // Cache the failure too, but with a shorter expiry (1 minute)
      profileCache.current[username] = {
        image: null,
        lastFetched: now - cacheExpiryTime + (60 * 1000)
      };
    }
    
    return null;
  }, []);
  
  // Effect to fetch profile images for message senders
  useEffect(() => {
    // Create a unique list of usernames from messages
    const usernames = Array.from(new Set(messages.map(msg => msg.user)));
    
    // For each username, fetch the profile image if not already cached
    usernames.forEach(username => {
      if (!userProfileImages[username]) {
        fetchUserProfileImage(username);
      }
    });
  }, [messages, fetchUserProfileImage, userProfileImages]);

  // Send message through WebSocket
  const sendMessage = useCallback((payload: ChatPayload) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      try {
        const message = {
          type: "message",
          payload: {
            ...payload,
            timestamp: new Date().toISOString(),
          },
        };
        
        console.log('Sending message:', message);
        socket.send(JSON.stringify(message));
      } catch (error) {
        console.error('Error sending message:', error);
        toast({
          title: "Error sending message",
          description: "There was a problem sending your message. Please try again.",
          variant: "destructive",
        });
      }
    } else {
      console.warn('Socket not ready:', socket ? socket.readyState : 'no socket');
      toast({
        title: "Could not send message",
        description: "You are currently disconnected from the chat server.",
        variant: "destructive",
      });
    }
  }, [socket, toast]);

  // Function to get a user's profile image
  const getUserProfileImage = useCallback((username: string) => {
    // If we have it in state, return it
    if (userProfileImages[username] !== undefined) {
      return userProfileImages[username];
    }
    
    // Otherwise check cache
    const cachedData = profileCache.current[username];
    if (cachedData) {
      return cachedData.image;
    }
    
    // If not in cache, trigger fetch and return null for now
    fetchUserProfileImage(username);
    return null;
  }, [userProfileImages, fetchUserProfileImage]);

  return {
    messages,
    onlineUsers,
    sendMessage,
    isConnecting,
    getUserProfileImage,
  };
}
