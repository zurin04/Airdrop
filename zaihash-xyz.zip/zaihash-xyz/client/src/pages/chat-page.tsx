import { useEffect } from "react";
import { Helmet } from "react-helmet";
import Sidebar from "@/components/layout/sidebar";
import Footer from "@/components/layout/footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useGlobalChat } from "@/hooks/use-global-chat";

export default function ChatPage() {
  const { enableChat } = useGlobalChat();
  
  // Enable floating chat when this page is visited
  useEffect(() => {
    enableChat();
    // No need to disable on unmount as we want the chat to persist
  }, [enableChat]);

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Helmet>
        <title>Community Chat - Crypto Airdrop Task Hub</title>
        <meta name="description" content="Join our crypto community chat to discuss airdrops, ask questions, and connect with other crypto enthusiasts in real-time." />
      </Helmet>
      
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="hero-bg p-6 md:p-10">
          <div className="max-w-5xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-4 text-white">Community <span className="text-primary">Chat</span></h1>
            <p className="text-gray-300 mb-6">Connect with other crypto enthusiasts, ask questions about airdrops, and share your experiences.</p>
          </div>
        </div>
        
        <div className="p-6 md:p-10">
          <div className="max-w-5xl mx-auto">
            <Card className="shadow-lg border border-gray-800 mb-8">
              <CardHeader>
                <CardTitle>Chat is now available across the entire site!</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 mb-4">
                  You can now access the community chat from any page on the site. Look for the chat bubble in the bottom-left corner of your screen!
                </p>
                <p className="text-gray-300">
                  The chat allows you to stay connected with the community while browsing different airdrops and completing tasks.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Chat Guidelines</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Be respectful to other community members.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>No spam, promotional links, or unsolicited referral codes.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Do not share personal information like wallet addresses or seed phrases.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Avoid discussing price speculation or investment advice.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Report any suspicious activities to moderators.</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <div className="mt-8">
              <Button 
                className="w-full flex items-center justify-center space-x-2" 
                onClick={() => enableChat()}
                size="lg"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
                <span>Open Chat</span>
              </Button>
            </div>
          </div>
        </div>
        
        <Footer />
      </main>
    </div>
  );
}
