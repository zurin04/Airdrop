#!/bin/bash

# Quick fix for Nginx configuration issue
# This script properly enables the crypto-airdrop site and disables the default

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}▶${NC} $1"; }
print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }

print_status "Fixing Nginx configuration..."

# Check if crypto-airdrop site exists
if [ ! -f "/etc/nginx/sites-available/crypto-airdrop" ]; then
    print_error "Nginx site configuration not found at /etc/nginx/sites-available/crypto-airdrop"
    echo "Please run the full deployment script first: ./deploy.sh"
    exit 1
fi

# Enable crypto-airdrop site
print_status "Enabling crypto-airdrop site..."
sudo ln -sf /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/

# Remove default site
print_status "Removing default Nginx site..."
sudo rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
print_status "Testing Nginx configuration..."
if sudo nginx -t; then
    print_success "Nginx configuration is valid"
else
    print_error "Nginx configuration has errors"
    exit 1
fi

# Restart Nginx to ensure changes take effect
print_status "Restarting Nginx..."
sudo systemctl restart nginx

if sudo systemctl is-active --quiet nginx; then
    print_success "Nginx restarted successfully"
else
    print_error "Nginx failed to restart"
    exit 1
fi

# Check if application is running
print_status "Checking application status..."
if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200\|302"; then
    print_success "Application is responding correctly"
else
    print_error "Application is not responding"
    echo "Check PM2 status: pm2 status"
    echo "Check PM2 logs: pm2 logs crypto-airdrop"
fi

# Get server IP for testing
server_ip=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null || \
           curl -s --connect-timeout 5 icanhazip.com 2>/dev/null || \
           hostname -I | awk '{print $1}' || \
           echo "localhost")

echo ""
print_success "Nginx fix completed!"
echo ""
echo "Test your application:"
echo "• Local: curl -I http://localhost"
echo "• External: curl -I http://$server_ip"
echo "• Browser: http://$server_ip"
echo ""
echo "If you still see the Nginx welcome page, wait 30 seconds and try again."