#!/bin/bash

# Port Diagnostic Script for Crypto Airdrop Platform
# Helps troubleshoot connectivity and port issues

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() { echo -e "${BLUE}=== $1 ===${NC}"; }
print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_warning() { echo -e "${YELLOW}⚠${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }

# Get server IP
get_server_ip() {
    local server_ip=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null || \
                     curl -s --connect-timeout 5 icanhazip.com 2>/dev/null || \
                     hostname -I | awk '{print $1}' || \
                     ip route get 8.8.8.8 | awk '/src/ {print $7}' 2>/dev/null || \
                     echo "localhost")
    echo "$server_ip"
}

# Check listening ports
check_listening_ports() {
    print_header "Listening Ports Check"
    
    echo "Checking common application ports..."
    
    # Check port 80 (Nginx)
    if netstat -tlnp 2>/dev/null | grep -q ":80 "; then
        print_success "Port 80 (HTTP/Nginx) is listening"
        local nginx_pid=$(netstat -tlnp 2>/dev/null | grep ":80 " | awk '{print $7}' | cut -d'/' -f1)
        echo "  Process: $nginx_pid (nginx)"
    else
        print_error "Port 80 (HTTP/Nginx) is NOT listening"
    fi
    
    # Check port 3000 (Common dev port)
    if netstat -tlnp 2>/dev/null | grep -q ":3000 "; then
        print_success "Port 3000 (Application) is listening"
        local app_pid=$(netstat -tlnp 2>/dev/null | grep ":3000 " | awk '{print $7}' | cut -d'/' -f1)
        echo "  Process: $app_pid"
    else
        print_warning "Port 3000 (Application) is NOT listening"
    fi
    
    # Check port 5000 (Application)
    if netstat -tlnp 2>/dev/null | grep -q ":5000 "; then
        print_success "Port 5000 (Application) is listening"
        local app_pid=$(netstat -tlnp 2>/dev/null | grep ":5000 " | awk '{print $7}' | cut -d'/' -f1)
        echo "  Process: $app_pid"
    else
        print_warning "Port 5000 (Application) is NOT listening"
    fi
    
    # Check port 5432 (PostgreSQL)
    if netstat -tlnp 2>/dev/null | grep -q ":5432 "; then
        print_success "Port 5432 (PostgreSQL) is listening"
    else
        print_warning "Port 5432 (PostgreSQL) is NOT listening"
    fi
    
    echo ""
    echo "All listening ports:"
    netstat -tlnp 2>/dev/null | grep LISTEN | sort
}

# Check services status
check_services() {
    print_header "Service Status Check"
    
    # Check Nginx
    if systemctl is-active --quiet nginx 2>/dev/null; then
        print_success "Nginx service is running"
    else
        print_error "Nginx service is NOT running"
        echo "  Try: sudo systemctl start nginx"
    fi
    
    # Check PostgreSQL
    if systemctl is-active --quiet postgresql 2>/dev/null; then
        print_success "PostgreSQL service is running"
    else
        print_error "PostgreSQL service is NOT running"
        echo "  Try: sudo systemctl start postgresql"
    fi
    
    # Check PM2
    if command -v pm2 >/dev/null && pm2 list | grep -q "crypto-airdrop"; then
        if pm2 list | grep -q "crypto-airdrop.*online"; then
            print_success "PM2 application is running"
        else
            print_error "PM2 application is NOT running"
            echo "  Try: pm2 start crypto-airdrop"
        fi
    else
        print_error "PM2 application not found"
        echo "  Check if PM2 is installed and application is configured"
    fi
}

# Test HTTP connectivity
test_http_connectivity() {
    print_header "HTTP Connectivity Test"
    
    local server_ip=$(get_server_ip)
    echo "Testing connectivity to: $server_ip"
    echo ""
    
    # Test localhost
    echo "Testing localhost connections..."
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:80 2>/dev/null | grep -q "200\|302\|404"; then
        print_success "localhost:80 responds"
    else
        print_error "localhost:80 does NOT respond"
    fi
    
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null | grep -q "200\|302\|404"; then
        print_success "localhost:3000 responds"
    else
        print_warning "localhost:3000 does NOT respond"
    fi
    
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:5000 2>/dev/null | grep -q "200\|302\|404"; then
        print_success "localhost:5000 responds"
    else
        print_warning "localhost:5000 does NOT respond"
    fi
    
    echo ""
    
    # Test external IP
    if [[ "$server_ip" != "localhost" ]]; then
        echo "Testing external IP connections..."
        if curl -s -o /dev/null -w "%{http_code}" http://$server_ip 2>/dev/null | grep -q "200\|302\|404"; then
            print_success "External IP $server_ip responds"
        else
            print_error "External IP $server_ip does NOT respond"
            echo "  This could be a firewall issue"
        fi
    fi
}

# Check firewall status
check_firewall() {
    print_header "Firewall Status Check"
    
    if command -v ufw >/dev/null; then
        local ufw_status=$(sudo ufw status 2>/dev/null | head -n1)
        echo "UFW Status: $ufw_status"
        
        if sudo ufw status | grep -q "80/tcp.*ALLOW"; then
            print_success "Port 80 is allowed in firewall"
        else
            print_warning "Port 80 may be blocked by firewall"
            echo "  Try: sudo ufw allow 80/tcp"
        fi
        
        echo ""
        echo "Current UFW rules:"
        sudo ufw status numbered 2>/dev/null || echo "Could not get UFW rules"
    else
        print_warning "UFW firewall not found"
    fi
    
    # Check iptables if available
    if command -v iptables >/dev/null; then
        echo ""
        echo "Checking iptables rules for port 80..."
        if sudo iptables -L INPUT -n | grep -q "80"; then
            print_success "Port 80 found in iptables rules"
        else
            print_warning "Port 80 not explicitly found in iptables"
        fi
    fi
}

# Check Nginx configuration
check_nginx_config() {
    print_header "Nginx Configuration Check"
    
    if [ -f "/etc/nginx/sites-available/crypto-airdrop" ]; then
        print_success "Nginx site configuration exists"
        
        # Check what port Nginx is proxying to
        local proxy_port=$(grep "proxy_pass" /etc/nginx/sites-available/crypto-airdrop | head -n1 | grep -o ":[0-9]*" | tr -d ':')
        if [ -n "$proxy_port" ]; then
            echo "  Nginx is proxying to port: $proxy_port"
            
            # Check if that port is listening
            if netstat -tlnp 2>/dev/null | grep -q ":$proxy_port "; then
                print_success "Target port $proxy_port is listening"
            else
                print_error "Target port $proxy_port is NOT listening"
                echo "  The application may not be running on the expected port"
            fi
        fi
        
        # Test Nginx configuration
        if sudo nginx -t 2>/dev/null; then
            print_success "Nginx configuration is valid"
        else
            print_error "Nginx configuration has errors"
            echo "  Run: sudo nginx -t"
        fi
        
    else
        print_error "Nginx site configuration not found"
        echo "  Expected: /etc/nginx/sites-available/crypto-airdrop"
    fi
}

# Check application logs
check_logs() {
    print_header "Recent Log Check"
    
    # PM2 logs
    if command -v pm2 >/dev/null; then
        echo "Recent PM2 errors (last 10 lines):"
        pm2 logs crypto-airdrop --lines 10 --err 2>/dev/null || echo "No PM2 logs found"
        echo ""
    fi
    
    # Nginx error logs
    if [ -f "/var/log/nginx/error.log" ]; then
        echo "Recent Nginx errors (last 5 lines):"
        sudo tail -n 5 /var/log/nginx/error.log 2>/dev/null || echo "No recent Nginx errors"
        echo ""
    fi
    
    # System logs for nginx
    echo "Recent system logs for nginx:"
    sudo journalctl -u nginx --lines=5 --no-pager 2>/dev/null || echo "No nginx system logs found"
}

# Display summary and recommendations
display_summary() {
    print_header "Summary & Recommendations"
    
    local server_ip=$(get_server_ip)
    
    echo "Server IP: $server_ip"
    echo ""
    
    echo "Quick fixes to try:"
    echo "1. Restart services:"
    echo "   sudo systemctl restart nginx"
    echo "   pm2 restart crypto-airdrop"
    echo ""
    echo "2. Check firewall:"
    echo "   sudo ufw status"
    echo "   sudo ufw allow 80/tcp"
    echo ""
    echo "3. Test connectivity:"
    echo "   curl -I http://localhost"
    echo "   curl -I http://$server_ip"
    echo ""
    echo "4. Check application port in package.json and PM2 config"
    echo "5. Verify Nginx is proxying to the correct port"
    echo ""
    echo "For detailed troubleshooting, see README-VPS-DEPLOYMENT.md"
}

# Main execution
main() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║          Crypto Airdrop Platform - Port Diagnostic          ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    check_listening_ports
    echo ""
    check_services
    echo ""
    test_http_connectivity
    echo ""
    check_firewall
    echo ""
    check_nginx_config
    echo ""
    check_logs
    echo ""
    display_summary
}

# Execute main function
main "$@"